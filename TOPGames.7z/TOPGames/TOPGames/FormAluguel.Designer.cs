﻿
namespace TOPGames
{
    partial class FormAluguel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLocalizarID = new System.Windows.Forms.Button();
            this.dgvId = new System.Windows.Forms.DataGridView();
            this.btnAtualizarLocacao = new System.Windows.Forms.Button();
            this.txtIdJogo = new System.Windows.Forms.TextBox();
            this.lblIdJogo = new System.Windows.Forms.Label();
            this.txtTotalGeral = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnExcluirJogo = new System.Windows.Forms.Button();
            this.btnAtualizarJogo = new System.Windows.Forms.Button();
            this.btnAdicionarJogo = new System.Windows.Forms.Button();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.cbxJogo = new System.Windows.Forms.ComboBox();
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.lblPreco = new System.Windows.Forms.Label();
            this.btnLocar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnFinalizarLocacao = new System.Windows.Forms.Button();
            this.btnNovaLocacao = new System.Windows.Forms.Button();
            this.lblQuantidade = new System.Windows.Forms.Label();
            this.lblProduto = new System.Windows.Forms.Label();
            this.dgvVenda = new System.Windows.Forms.DataGridView();
            this.txtLocacao = new System.Windows.Forms.TextBox();
            this.lblLocacao = new System.Windows.Forms.Label();
            this.btnLocalizar = new System.Windows.Forms.Button();
            this.cbxCliente = new System.Windows.Forms.ComboBox();
            this.lblCliente = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVenda)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLocalizarID
            // 
            this.btnLocalizarID.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnLocalizarID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalizarID.ForeColor = System.Drawing.Color.White;
            this.btnLocalizarID.Location = new System.Drawing.Point(796, 25);
            this.btnLocalizarID.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnLocalizarID.Name = "btnLocalizarID";
            this.btnLocalizarID.Size = new System.Drawing.Size(113, 23);
            this.btnLocalizarID.TabIndex = 187;
            this.btnLocalizarID.Text = "Localizar ID";
            this.btnLocalizarID.UseVisualStyleBackColor = false;
            this.btnLocalizarID.Click += new System.EventHandler(this.btnLocalizarID_Click);
            // 
            // dgvId
            // 
            this.dgvId.AllowUserToAddRows = false;
            this.dgvId.AllowUserToDeleteRows = false;
            this.dgvId.BackgroundColor = System.Drawing.Color.White;
            this.dgvId.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvId.Location = new System.Drawing.Point(693, 54);
            this.dgvId.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dgvId.Name = "dgvId";
            this.dgvId.ReadOnly = true;
            this.dgvId.Size = new System.Drawing.Size(216, 389);
            this.dgvId.TabIndex = 186;
            // 
            // btnAtualizarLocacao
            // 
            this.btnAtualizarLocacao.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAtualizarLocacao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAtualizarLocacao.ForeColor = System.Drawing.Color.White;
            this.btnAtualizarLocacao.Location = new System.Drawing.Point(559, 83);
            this.btnAtualizarLocacao.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAtualizarLocacao.Name = "btnAtualizarLocacao";
            this.btnAtualizarLocacao.Size = new System.Drawing.Size(126, 23);
            this.btnAtualizarLocacao.TabIndex = 174;
            this.btnAtualizarLocacao.Text = "Atualizar Locação";
            this.btnAtualizarLocacao.UseVisualStyleBackColor = false;
            this.btnAtualizarLocacao.Click += new System.EventHandler(this.btnAtualizarPedido_Click);
            // 
            // txtIdJogo
            // 
            this.txtIdJogo.Location = new System.Drawing.Point(205, 146);
            this.txtIdJogo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtIdJogo.Name = "txtIdJogo";
            this.txtIdJogo.Size = new System.Drawing.Size(107, 20);
            this.txtIdJogo.TabIndex = 166;
            // 
            // lblIdJogo
            // 
            this.lblIdJogo.AutoSize = true;
            this.lblIdJogo.Location = new System.Drawing.Point(202, 130);
            this.lblIdJogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIdJogo.Name = "lblIdJogo";
            this.lblIdJogo.Size = new System.Drawing.Size(51, 13);
            this.lblIdJogo.TabIndex = 185;
            this.lblIdJogo.Text = "ID Jogo";
            // 
            // txtTotalGeral
            // 
            this.txtTotalGeral.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalGeral.Location = new System.Drawing.Point(499, 449);
            this.txtTotalGeral.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTotalGeral.Name = "txtTotalGeral";
            this.txtTotalGeral.Size = new System.Drawing.Size(186, 29);
            this.txtTotalGeral.TabIndex = 184;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(435, 452);
            this.lblTotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(56, 24);
            this.lblTotal.TabIndex = 183;
            this.lblTotal.Text = "Total";
            // 
            // btnExcluirJogo
            // 
            this.btnExcluirJogo.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnExcluirJogo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluirJogo.ForeColor = System.Drawing.Color.White;
            this.btnExcluirJogo.Location = new System.Drawing.Point(304, 240);
            this.btnExcluirJogo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExcluirJogo.Name = "btnExcluirJogo";
            this.btnExcluirJogo.Size = new System.Drawing.Size(136, 23);
            this.btnExcluirJogo.TabIndex = 171;
            this.btnExcluirJogo.Text = "Excluir Jogo";
            this.btnExcluirJogo.UseVisualStyleBackColor = false;
            this.btnExcluirJogo.Click += new System.EventHandler(this.btnExcluirJogo_Click);
            // 
            // btnAtualizarJogo
            // 
            this.btnAtualizarJogo.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAtualizarJogo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAtualizarJogo.ForeColor = System.Drawing.Color.White;
            this.btnAtualizarJogo.Location = new System.Drawing.Point(160, 240);
            this.btnAtualizarJogo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAtualizarJogo.Name = "btnAtualizarJogo";
            this.btnAtualizarJogo.Size = new System.Drawing.Size(136, 23);
            this.btnAtualizarJogo.TabIndex = 170;
            this.btnAtualizarJogo.Text = "Atualizar Jogo";
            this.btnAtualizarJogo.UseVisualStyleBackColor = false;
            this.btnAtualizarJogo.Click += new System.EventHandler(this.btnAtualizarJogo_Click);
            // 
            // btnAdicionarJogo
            // 
            this.btnAdicionarJogo.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAdicionarJogo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdicionarJogo.ForeColor = System.Drawing.Color.White;
            this.btnAdicionarJogo.Location = new System.Drawing.Point(16, 240);
            this.btnAdicionarJogo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAdicionarJogo.Name = "btnAdicionarJogo";
            this.btnAdicionarJogo.Size = new System.Drawing.Size(136, 23);
            this.btnAdicionarJogo.TabIndex = 169;
            this.btnAdicionarJogo.Text = "Adicionar Jogo";
            this.btnAdicionarJogo.UseVisualStyleBackColor = false;
            this.btnAdicionarJogo.Click += new System.EventHandler(this.btnAdicionarJogo_Click);
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Location = new System.Drawing.Point(16, 146);
            this.txtQuantidade.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(181, 20);
            this.txtQuantidade.TabIndex = 165;
            this.txtQuantidade.Leave += new System.EventHandler(this.txtQuantidade_Leave);
            // 
            // cbxJogo
            // 
            this.cbxJogo.FormattingEnabled = true;
            this.cbxJogo.Location = new System.Drawing.Point(16, 106);
            this.cbxJogo.Name = "cbxJogo";
            this.cbxJogo.Size = new System.Drawing.Size(441, 21);
            this.cbxJogo.TabIndex = 164;
            this.cbxJogo.SelectedIndexChanged += new System.EventHandler(this.cbxJogo_SelectedIndexChanged);
            // 
            // txtPreco
            // 
            this.txtPreco.Location = new System.Drawing.Point(16, 185);
            this.txtPreco.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.Size = new System.Drawing.Size(181, 20);
            this.txtPreco.TabIndex = 167;
            // 
            // lblPreco
            // 
            this.lblPreco.AutoSize = true;
            this.lblPreco.Location = new System.Drawing.Point(13, 169);
            this.lblPreco.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPreco.Name = "lblPreco";
            this.lblPreco.Size = new System.Drawing.Size(40, 13);
            this.lblPreco.TabIndex = 182;
            this.lblPreco.Text = "Preço";
            // 
            // btnLocar
            // 
            this.btnLocar.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnLocar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocar.ForeColor = System.Drawing.Color.White;
            this.btnLocar.Location = new System.Drawing.Point(559, 112);
            this.btnLocar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnLocar.Name = "btnLocar";
            this.btnLocar.Size = new System.Drawing.Size(126, 23);
            this.btnLocar.TabIndex = 175;
            this.btnLocar.Text = "Locar";
            this.btnLocar.UseVisualStyleBackColor = false;
            this.btnLocar.Click += new System.EventHandler(this.btnLocar_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.ForeColor = System.Drawing.Color.White;
            this.btnSair.Location = new System.Drawing.Point(559, 141);
            this.btnSair.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(126, 23);
            this.btnSair.TabIndex = 176;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            // 
            // btnFinalizarLocacao
            // 
            this.btnFinalizarLocacao.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnFinalizarLocacao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFinalizarLocacao.ForeColor = System.Drawing.Color.White;
            this.btnFinalizarLocacao.Location = new System.Drawing.Point(559, 54);
            this.btnFinalizarLocacao.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFinalizarLocacao.Name = "btnFinalizarLocacao";
            this.btnFinalizarLocacao.Size = new System.Drawing.Size(126, 23);
            this.btnFinalizarLocacao.TabIndex = 173;
            this.btnFinalizarLocacao.Text = "Finalizar Locação";
            this.btnFinalizarLocacao.UseVisualStyleBackColor = false;
            this.btnFinalizarLocacao.Click += new System.EventHandler(this.btnFinalizarPedido_Click);
            // 
            // btnNovaLocacao
            // 
            this.btnNovaLocacao.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnNovaLocacao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovaLocacao.ForeColor = System.Drawing.Color.White;
            this.btnNovaLocacao.Location = new System.Drawing.Point(559, 25);
            this.btnNovaLocacao.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnNovaLocacao.Name = "btnNovaLocacao";
            this.btnNovaLocacao.Size = new System.Drawing.Size(126, 23);
            this.btnNovaLocacao.TabIndex = 172;
            this.btnNovaLocacao.Text = "Nova Locação";
            this.btnNovaLocacao.UseVisualStyleBackColor = false;
            this.btnNovaLocacao.Click += new System.EventHandler(this.btnNovoPedido_Click);
            // 
            // lblQuantidade
            // 
            this.lblQuantidade.AutoSize = true;
            this.lblQuantidade.Location = new System.Drawing.Point(13, 130);
            this.lblQuantidade.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQuantidade.Name = "lblQuantidade";
            this.lblQuantidade.Size = new System.Drawing.Size(72, 13);
            this.lblQuantidade.TabIndex = 181;
            this.lblQuantidade.Text = "Quantidade";
            // 
            // lblProduto
            // 
            this.lblProduto.AutoSize = true;
            this.lblProduto.Location = new System.Drawing.Point(13, 90);
            this.lblProduto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProduto.Name = "lblProduto";
            this.lblProduto.Size = new System.Drawing.Size(34, 13);
            this.lblProduto.TabIndex = 180;
            this.lblProduto.Text = "Jogo";
            // 
            // dgvVenda
            // 
            this.dgvVenda.AllowUserToAddRows = false;
            this.dgvVenda.AllowUserToDeleteRows = false;
            this.dgvVenda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVenda.Location = new System.Drawing.Point(16, 269);
            this.dgvVenda.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dgvVenda.Name = "dgvVenda";
            this.dgvVenda.ReadOnly = true;
            this.dgvVenda.Size = new System.Drawing.Size(669, 174);
            this.dgvVenda.TabIndex = 178;
            this.dgvVenda.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVenda_CellClick);
            // 
            // txtLocacao
            // 
            this.txtLocacao.Location = new System.Drawing.Point(16, 27);
            this.txtLocacao.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtLocacao.Name = "txtLocacao";
            this.txtLocacao.Size = new System.Drawing.Size(139, 20);
            this.txtLocacao.TabIndex = 162;
            // 
            // lblLocacao
            // 
            this.lblLocacao.AutoSize = true;
            this.lblLocacao.Location = new System.Drawing.Point(13, 9);
            this.lblLocacao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLocacao.Name = "lblLocacao";
            this.lblLocacao.Size = new System.Drawing.Size(56, 13);
            this.lblLocacao.TabIndex = 177;
            this.lblLocacao.Text = "Locação";
            // 
            // btnLocalizar
            // 
            this.btnLocalizar.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnLocalizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalizar.ForeColor = System.Drawing.Color.White;
            this.btnLocalizar.Location = new System.Drawing.Point(163, 25);
            this.btnLocalizar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnLocalizar.Name = "btnLocalizar";
            this.btnLocalizar.Size = new System.Drawing.Size(127, 23);
            this.btnLocalizar.TabIndex = 168;
            this.btnLocalizar.Text = "Localizar Locação";
            this.btnLocalizar.UseVisualStyleBackColor = false;
            this.btnLocalizar.Click += new System.EventHandler(this.btnLocalizar_Click);
            // 
            // cbxCliente
            // 
            this.cbxCliente.FormattingEnabled = true;
            this.cbxCliente.Location = new System.Drawing.Point(16, 66);
            this.cbxCliente.Name = "cbxCliente";
            this.cbxCliente.Size = new System.Drawing.Size(441, 21);
            this.cbxCliente.TabIndex = 188;
            // 
            // lblCliente
            // 
            this.lblCliente.AutoSize = true;
            this.lblCliente.Location = new System.Drawing.Point(13, 50);
            this.lblCliente.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCliente.Name = "lblCliente";
            this.lblCliente.Size = new System.Drawing.Size(46, 13);
            this.lblCliente.TabIndex = 189;
            this.lblCliente.Text = "Cliente";
            // 
            // FormAluguel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(930, 569);
            this.Controls.Add(this.cbxCliente);
            this.Controls.Add(this.lblCliente);
            this.Controls.Add(this.btnLocalizarID);
            this.Controls.Add(this.dgvId);
            this.Controls.Add(this.btnAtualizarLocacao);
            this.Controls.Add(this.txtIdJogo);
            this.Controls.Add(this.lblIdJogo);
            this.Controls.Add(this.txtTotalGeral);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.btnExcluirJogo);
            this.Controls.Add(this.btnAtualizarJogo);
            this.Controls.Add(this.btnAdicionarJogo);
            this.Controls.Add(this.txtQuantidade);
            this.Controls.Add(this.cbxJogo);
            this.Controls.Add(this.txtPreco);
            this.Controls.Add(this.lblPreco);
            this.Controls.Add(this.btnLocar);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnFinalizarLocacao);
            this.Controls.Add(this.btnNovaLocacao);
            this.Controls.Add(this.lblQuantidade);
            this.Controls.Add(this.lblProduto);
            this.Controls.Add(this.dgvVenda);
            this.Controls.Add(this.txtLocacao);
            this.Controls.Add(this.lblLocacao);
            this.Controls.Add(this.btnLocalizar);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FormAluguel";
            this.Text = "FormAluguel";
            this.Load += new System.EventHandler(this.FormAluguel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVenda)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLocalizarID;
        private System.Windows.Forms.DataGridView dgvId;
        private System.Windows.Forms.Button btnAtualizarLocacao;
        private System.Windows.Forms.TextBox txtIdJogo;
        private System.Windows.Forms.Label lblIdJogo;
        private System.Windows.Forms.TextBox txtTotalGeral;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnExcluirJogo;
        private System.Windows.Forms.Button btnAtualizarJogo;
        private System.Windows.Forms.Button btnAdicionarJogo;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.ComboBox cbxJogo;
        private System.Windows.Forms.TextBox txtPreco;
        private System.Windows.Forms.Label lblPreco;
        private System.Windows.Forms.Button btnLocar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnFinalizarLocacao;
        private System.Windows.Forms.Button btnNovaLocacao;
        private System.Windows.Forms.Label lblQuantidade;
        private System.Windows.Forms.Label lblProduto;
        private System.Windows.Forms.DataGridView dgvVenda;
        private System.Windows.Forms.TextBox txtLocacao;
        private System.Windows.Forms.Label lblLocacao;
        private System.Windows.Forms.Button btnLocalizar;
        private System.Windows.Forms.ComboBox cbxCliente;
        private System.Windows.Forms.Label lblCliente;
    }
}